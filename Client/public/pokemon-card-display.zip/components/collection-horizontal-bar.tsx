"use client"

import { useState } from "react"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, Search, ChevronRight } from "lucide-react"
import { Input } from "@/components/ui/input"

interface Collection {
  id: string
  name: string
  icon: string
  subcollections?: Collection[]
}

const collections: Collection[] = [
  {
    id: "scarlet-violet",
    name: "Scarlet & Violet",
    icon: "SVE",
    subcollections: [
      { id: "prismatic", name: "Prismatic Evolutions", icon: "PRE" },
      { id: "surging-sparks", name: "Surging Sparks", icon: "SSP" },
      { id: "stellar-crown", name: "Stellar Crown", icon: "SCR" },
      { id: "shrouded-fable", name: "Shrouded Fable", icon: "SFA" },
      { id: "twilight-masquerade", name: "Twilight Masquerade", icon: "TWM" },
      { id: "temporal-forces", name: "Temporal Forces", icon: "TEF" },
      { id: "paldean-fates", name: "Paldean Fates", icon: "PAF" },
      { id: "paradox-rift", name: "Paradox Rift", icon: "PAR" },
      { id: "151", name: "151", icon: "151" },
      { id: "obsidian-flames", name: "Obsidian Flames", icon: "OBF" },
      { id: "paldea-evolved", name: "Paldea Evolved", icon: "PAL" },
      { id: "scarlet-violet-base", name: "Scarlet & Violet", icon: "SVE" },
    ],
  },
  {
    id: "sword-shield",
    name: "Sword & Shield",
    icon: "SWS",
    subcollections: [
      { id: "crown-zenith", name: "Crown Zenith", icon: "CRZ" },
      { id: "silver-tempest", name: "Silver Tempest", icon: "SIT" },
      { id: "lost-origin", name: "Lost Origin", icon: "LOR" },
      { id: "pokemon-go", name: "Pokémon GO", icon: "PGO" },
    ],
  },
  {
    id: "sun-moon",
    name: "Sun & Moon",
    icon: "SNM",
    subcollections: [
      { id: "cosmic-eclipse", name: "Cosmic Eclipse", icon: "CEC" },
      { id: "unified-minds", name: "Unified Minds", icon: "UNM" },
      { id: "unbroken-bonds", name: "Unbroken Bonds", icon: "UNB" },
      { id: "team-up", name: "Team Up", icon: "TEU" },
    ],
  },
  {
    id: "xy",
    name: "XY",
    icon: "XY",
    subcollections: [
      { id: "evolutions", name: "Evolutions", icon: "EVO" },
      { id: "steam-siege", name: "Steam Siege", icon: "STS" },
      { id: "fates-collide", name: "Fates Collide", icon: "FCO" },
      { id: "breakpoint", name: "BREAKpoint", icon: "BKP" },
    ],
  },
  {
    id: "black-white",
    name: "Black & White",
    icon: "BNW",
    subcollections: [
      { id: "legendary-treasures", name: "Legendary Treasures", icon: "LTR" },
      { id: "plasma-blast", name: "Plasma Blast", icon: "PLB" },
      { id: "plasma-freeze", name: "Plasma Freeze", icon: "PLF" },
      { id: "plasma-storm", name: "Plasma Storm", icon: "PLS" },
    ],
  },
]

export function CollectionHorizontalBar() {
  const [expandedCollections, setExpandedCollections] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  const filteredCollections = collections
    .map((collection) => ({
      ...collection,
      subcollections: collection.subcollections?.filter((sub) =>
        sub.name.toLowerCase().includes(searchQuery.toLowerCase()),
      ),
    }))
    .filter(
      (collection) =>
        collection.name.toLowerCase().includes(searchQuery.toLowerCase()) || collection.subcollections?.length > 0,
    )

  const toggleCollection = (id: string) => {
    setExpandedCollections((prev) =>
      prev.includes(id) ? prev.filter((collectionId) => collectionId !== id) : [...prev, id],
    )
  }

  const toggleAll = () => {
    if (expandedCollections.length === collections.length) {
      setExpandedCollections([])
    } else {
      setExpandedCollections(collections.map((c) => c.id))
    }
  }

  return (
    <div className="w-full bg-gray-50 border-b">
      <div className="container mx-auto">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search a collection..."
              className="pl-10 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="ghost" onClick={toggleAll} className="flex items-center gap-2">
            {expandedCollections.length === collections.length ? (
              <>
                <ChevronUp className="h-4 w-4" />
                Fold all
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4" />
                Unfold all
              </>
            )}
          </Button>
        </div>

        <div className="p-4">
          <ScrollArea className="w-full">
            <div className="flex gap-4">
              {filteredCollections.map((collection) => (
                <div key={collection.id} className="min-w-[200px]">
                  <Button
                    variant="ghost"
                    className="w-full justify-start mb-2 hover:bg-gray-100"
                    onClick={() => toggleCollection(collection.id)}
                  >
                    <div className="flex items-center gap-2">
                      {expandedCollections.includes(collection.id) ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      <span className="flex items-center gap-2">
                        <span className="inline-flex items-center justify-center bg-blue-100 text-blue-800 rounded-full w-6 h-6 text-xs font-medium">
                          {collection.icon}
                        </span>
                        {collection.name}
                      </span>
                    </div>
                  </Button>

                  {expandedCollections.includes(collection.id) && collection.subcollections && (
                    <div className="ml-6 space-y-1">
                      {collection.subcollections.map((sub) => (
                        <Button key={sub.id} variant="ghost" className="w-full justify-start pl-6 hover:bg-gray-100">
                          <span className="flex items-center gap-2">
                            <span className="inline-flex items-center justify-center bg-gray-200 text-gray-700 rounded px-1.5 py-0.5 text-xs font-medium">
                              {sub.icon}
                            </span>
                            {sub.name}
                          </span>
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      </div>
    </div>
  )
}

